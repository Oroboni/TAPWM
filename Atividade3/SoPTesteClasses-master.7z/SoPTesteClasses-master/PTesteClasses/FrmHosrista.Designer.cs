﻿namespace PTesteClasses
{
    partial class FrmHosrista
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.button1 = new System.Windows.Forms.Button();
            this.TxtDataEntrada = new System.Windows.Forms.TextBox();
            this.TxtHora = new System.Windows.Forms.TextBox();
            this.TxtNome = new System.Windows.Forms.TextBox();
            this.TxtMatricula = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.TxtFaltas = new System.Windows.Forms.TextBox();
            this.Faltas = new System.Windows.Forms.Label();
            this.TxtSalario = new System.Windows.Forms.TextBox();
            this.LblHora = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(298, 321);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(205, 88);
            this.button1.TabIndex = 19;
            this.button1.Text = "Instanciar Horista";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // TxtDataEntrada
            // 
            this.TxtDataEntrada.Location = new System.Drawing.Point(383, 191);
            this.TxtDataEntrada.Name = "TxtDataEntrada";
            this.TxtDataEntrada.Size = new System.Drawing.Size(208, 26);
            this.TxtDataEntrada.TabIndex = 28;
            this.TxtDataEntrada.TextChanged += new System.EventHandler(this.TxtDataEntrada_TextChanged);
            // 
            // TxtHora
            // 
            this.TxtHora.Location = new System.Drawing.Point(383, 160);
            this.TxtHora.Name = "TxtHora";
            this.TxtHora.Size = new System.Drawing.Size(100, 26);
            this.TxtHora.TabIndex = 27;
            this.TxtHora.TextChanged += new System.EventHandler(this.TxtSalario_TextChanged);
            // 
            // TxtNome
            // 
            this.TxtNome.Location = new System.Drawing.Point(383, 94);
            this.TxtNome.Name = "TxtNome";
            this.TxtNome.Size = new System.Drawing.Size(310, 26);
            this.TxtNome.TabIndex = 26;
            this.TxtNome.TextChanged += new System.EventHandler(this.TxtNome_TextChanged);
            // 
            // TxtMatricula
            // 
            this.TxtMatricula.Location = new System.Drawing.Point(383, 60);
            this.TxtMatricula.Name = "TxtMatricula";
            this.TxtMatricula.Size = new System.Drawing.Size(100, 26);
            this.TxtMatricula.TabIndex = 25;
            this.TxtMatricula.TextChanged += new System.EventHandler(this.TxtMatricula_TextChanged_1);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(137, 191);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(208, 20);
            this.label5.TabIndex = 24;
            this.label5.Text = "Data de Entrda na Empresa";
            this.label5.Click += new System.EventHandler(this.label5_Click_1);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(232, 160);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(134, 20);
            this.label3.TabIndex = 23;
            this.label3.Text = "Numero de Horas";
            this.label3.Click += new System.EventHandler(this.label3_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(294, 94);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(51, 20);
            this.label2.TabIndex = 22;
            this.label2.Text = "Nome";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(272, 60);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(73, 20);
            this.label1.TabIndex = 21;
            this.label1.Text = "Matricula";
            // 
            // TxtFaltas
            // 
            this.TxtFaltas.Location = new System.Drawing.Point(383, 223);
            this.TxtFaltas.Name = "TxtFaltas";
            this.TxtFaltas.Size = new System.Drawing.Size(100, 26);
            this.TxtFaltas.TabIndex = 30;
            this.TxtFaltas.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // Faltas
            // 
            this.Faltas.AutoSize = true;
            this.Faltas.Location = new System.Drawing.Point(238, 229);
            this.Faltas.Name = "Faltas";
            this.Faltas.Size = new System.Drawing.Size(107, 20);
            this.Faltas.TabIndex = 29;
            this.Faltas.Text = "Dias Faltados";
            this.Faltas.Click += new System.EventHandler(this.Faltas_Click);
            // 
            // TxtSalario
            // 
            this.TxtSalario.Location = new System.Drawing.Point(383, 126);
            this.TxtSalario.Name = "TxtSalario";
            this.TxtSalario.Size = new System.Drawing.Size(100, 26);
            this.TxtSalario.TabIndex = 32;
            this.TxtSalario.TextChanged += new System.EventHandler(this.textBox2_TextChanged);
            // 
            // LblHora
            // 
            this.LblHora.AutoSize = true;
            this.LblHora.Location = new System.Drawing.Point(232, 126);
            this.LblHora.Name = "LblHora";
            this.LblHora.Size = new System.Drawing.Size(97, 20);
            this.LblHora.TabIndex = 31;
            this.LblHora.Text = "Salario Hora";
            this.LblHora.Click += new System.EventHandler(this.label4_Click);
            // 
            // FrmHosrista
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.TxtSalario);
            this.Controls.Add(this.LblHora);
            this.Controls.Add(this.TxtFaltas);
            this.Controls.Add(this.Faltas);
            this.Controls.Add(this.TxtDataEntrada);
            this.Controls.Add(this.TxtHora);
            this.Controls.Add(this.TxtNome);
            this.Controls.Add(this.TxtMatricula);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.button1);
            this.Name = "FrmHosrista";
            this.Text = "FrmHosrista";
            this.Load += new System.EventHandler(this.FrmHosrista_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox TxtDataEntrada;
        private System.Windows.Forms.TextBox TxtHora;
        private System.Windows.Forms.TextBox TxtNome;
        private System.Windows.Forms.TextBox TxtMatricula;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox TxtFaltas;
        private System.Windows.Forms.Label Faltas;
        private System.Windows.Forms.TextBox TxtSalario;
        private System.Windows.Forms.Label LblHora;
    }
}