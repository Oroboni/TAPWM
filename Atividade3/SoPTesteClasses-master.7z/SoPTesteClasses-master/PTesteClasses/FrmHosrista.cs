﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PTesteClasses
{
    public partial class FrmHosrista : Form
    {
        public FrmHosrista()
        {
            InitializeComponent();
        }

        private void TxtMatricula_TextChanged(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void TxtMatricula_TextChanged_1(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Horista objHorista = new Horista();

            objHorista.NomeEmpregado = TxtNome.Text;
            objHorista.Matricula = Convert.ToInt32(TxtMatricula.Text);
            objHorista.SalarioHora = Convert.ToDouble(TxtHora.Text);
            objHorista.NumeroHora = Convert.ToDouble(TxtHora.Text); 
            objHorista.DataEntradaEmpresa = Convert.ToDateTime(TxtDataEntrada.Text);
            objHorista.DiasFaltas = Convert.ToInt32(TxtFaltas.Text);

            MessageBox.Show("Nome: " + objHorista.NomeEmpregado + "\n" +
                "Matricula: " + objHorista.Matricula
                + "\n" + "Tempo Trabalho " + objHorista.TempoTrabalho() + "\n" +
                "Salário: " + objHorista.SalarioBruto().ToString("N2"));
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void Faltas_Click(object sender, EventArgs e)
        {

        }

        private void TxtDataEntrada_TextChanged(object sender, EventArgs e)
        {

        }

        private void TxtSalario_TextChanged(object sender, EventArgs e)
        {

        }

        private void label5_Click_1(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void TxtNome_TextChanged(object sender, EventArgs e)
        {

        }

        private void FrmHosrista_Load(object sender, EventArgs e)
        {

        }
    }
}
