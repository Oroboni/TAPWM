var a1 = parseFloat(prompt("Digite o primeiro número: "));
var a2 = parseFloat(prompt("Digite o segundo número: "));

var res = (a1 / a2).toFixed(2);

alert("Soma: " + (a1 + a2));
alert("Subtração: " + (a1 - a2));
alert("Multiplicação: " + (a1 * a2));
alert("Divisão: " + res);
alert("Resto: " + (a1 % a2));