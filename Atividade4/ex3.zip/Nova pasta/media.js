var a = prompt("Nome do Aluno");
var a1 = parseFloat(prompt("Nota 1"));
var a2 = parseFloat(prompt("Nome 2"));
var a3 = parseFloat(prompt("Nome 3"));

var resutado = (a1+a2+a3)/3;

alert("A média do aluno " + a + " é: " + resutado);